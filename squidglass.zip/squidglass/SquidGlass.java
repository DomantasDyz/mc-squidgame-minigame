package mc.glassevent.squidglass;

import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.*;

// Minecraft 1.20.* SquidGame stiklo minigame plugin'as

public final class SquidGlass extends JavaPlugin implements Listener {



    private Random random = new Random();
    private World world;

    private Location winner1, winner2;
    private Location death1, death2;
    private Location noWalk1, noWalk2;

    private Location eventZone1, eventZone2;

    private boolean isOn = false;

    private Material stiklas = Material.GLASS;

    List<Location> teisingiBlokai = new ArrayList<Location>();
    List<Location> neTeisingiBlokai = new ArrayList<Location>();

    List<Location> praeitiVisiTeisingiBlokai = new ArrayList<Location>();

    private Material melynavilna = Material.BLUE_WOOL;
    private Material juodavilna = Material.BLACK_WOOL;
    private Material redvilna = Material.RED_WOOL;

    Set<Player> dalyvaujantysZaidejai = new HashSet<Player>();

    HashMap<Player, Long> laikasAntBloko = new HashMap<>();


    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("SquidGlass event'as on!");

        world = Bukkit.getWorld("prisonold");

        winner1 = new Location(world, 747, 222, -2285);
        winner2 = new Location(world, 743, 222, -2283);
        death1 = new Location(world, 751, 213, -2245);
        death2 = new Location(world, 739, 213, -2282);
        eventZone1 = new Location(world, 751, 213, -2245);
        eventZone2 = new Location(world, 739, 227, -2282);
        noWalk1 = new Location(world, 745, 221, -2245);
        noWalk2 = new Location(world, 745, 223, -2282);

        List<Block> winnerBlokai = addWinnerBlocks(world, winner1, winner2, melynavilna);

        List<Block> deathZone =  vilnosBlokai(world, death1, death2, juodavilna);

    }

    @Override
    public void onDisable() {
        getLogger().info("SquidGlass event'as off!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("squidglass")) {
            if (args.length == 1 && args[0].equalsIgnoreCase("ijungti")) {
                if (sender.isOp()) {
                    if (!isOn) {
                        isOn = true;
                        generateRandomBlocks();
                        Component on = Component.text("")
                                .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                                .append(Component.text("SquidGlass Event").color(NamedTextColor.BLUE))
                                .append(Component.text("] ").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                                .append(Component.text(sender.getName()).color(net.kyori.adventure.text.format.NamedTextColor.GOLD))
                                .append(Component.text(" pradėjo SquidGlass event'ą!").color(net.kyori.adventure.text.format.NamedTextColor.GREEN));

                        for(Player zaidejai : Bukkit.getOnlinePlayers()) {
                            zaidejai.sendMessage(on);
                        }
                    } else {
                        Component alrOn = Component.text("")
                                .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                                .append(Component.text("SquidGlass Event").color(NamedTextColor.BLUE))
                                .append(Component.text("] ").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                                .append(Component.text("Event'as jau yra įjungtas!").color(net.kyori.adventure.text.format.NamedTextColor.RED));

                        sender.sendMessage(alrOn);
                    }
                } else {
                    Component denied = Component.text("")
                            .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                            .append(Component.text("SquidGlass Event").color(NamedTextColor.BLUE))
                            .append(Component.text("]").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                            .append(Component.text(" Šios komandos prieiga yra limituojama.").color(net.kyori.adventure.text.format.NamedTextColor.RED));

                    sender.sendMessage(denied);
                }
                return true;
            } else if (args.length == 1 && args[0].equalsIgnoreCase("isjungti")) {
                if(sender.isOp()) {
                    if (isOn) {
                        isOn = false;
                        teisingiBlokai.clear();
                        neTeisingiBlokai.clear();
                        praeitiVisiTeisingiBlokai.clear();
                        dalyvaujantysZaidejai.clear();
                        Component offintas = Component.text("")
                                .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                                .append(Component.text("SquidGlass Event").color(NamedTextColor.BLUE))
                                .append(Component.text("] ").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                                .append(Component.text(sender.getName()).color(net.kyori.adventure.text.format.NamedTextColor.GOLD))
                                .append(Component.text(" išjungė SquidGlass event'ą!").color(NamedTextColor.DARK_RED));

                        for (Player zaidejai : Bukkit.getOnlinePlayers()) {
                            zaidejai.sendMessage(offintas);
                        }
                    } else {
                        Component off = Component.text("")
                                .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                                .append(Component.text("SquidGlass Event").color(NamedTextColor.BLUE))
                                .append(Component.text("] ").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                                .append(Component.text("Event'as jau yra išjungtas!").color(net.kyori.adventure.text.format.NamedTextColor.RED));

                        sender.sendMessage(off);

                    }
                } else {
                    Component denied = Component.text("")
                            .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                            .append(Component.text("SquidGlass Event").color(NamedTextColor.BLUE))
                            .append(Component.text("]").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                            .append(Component.text(" Šios komandos prieiga yra limituojama.").color(net.kyori.adventure.text.format.NamedTextColor.RED));

                    sender.sendMessage(denied);
                }
            } else if (args.length == 1 && args[0].equals("prisijungti")) {
                if(isOn) {
                    Player prisijungiantis = (Player) sender;
                    dalyvaujantysZaidejai.add(prisijungiantis);
                    for(Player dalyvaujantys : dalyvaujantysZaidejai) {
                        dalyvaujantys.setCollidable(false);
                    }

                    Component joined = Component.text("")
                            .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                            .append(Component.text("SquidGlass Event").color(NamedTextColor.BLUE))
                            .append(Component.text("] ").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                            .append(Component.text(sender.getName()).color(net.kyori.adventure.text.format.NamedTextColor.GOLD))
                            .append(Component.text(" prisijungė į SquidGlass event!").color(NamedTextColor.DARK_RED));

                    Bukkit.broadcast(joined);
                }
            } else if (args.length == 0) {
                Component info0 = Component.text("")
                        .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                        .append(Component.text("SquidGlass Event")).color(NamedTextColor.BLUE)
                        .append(Component.text("] ").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                        .append(Component.text("NOTICE: Šio event plugin'as nebėra support'inamas!").color(NamedTextColor.DARK_RED));
                Component info = Component.text("")
                        .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                        .append(Component.text("SquidGlass Event")).color(NamedTextColor.BLUE)
                        .append(Component.text("] ").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                        .append(Component.text("Komandų sąrašas:").color(net.kyori.adventure.text.format.NamedTextColor.GOLD));
                Component info2 = Component.text("")
                        .append(Component.text("1. /squidglass").color(NamedTextColor.GOLD))
                        .append(Component.text(" - parodo visas event komandas.").color(NamedTextColor.DARK_GREEN));
                Component info3 = Component.text("")
                        .append(Component.text("2. /squidglass ijungti").color(NamedTextColor.GOLD))
                        .append(Component.text(" - pradeda event.").color(NamedTextColor.DARK_GREEN));
                Component info4 = Component.text("")
                        .append(Component.text("3. /squidglass prisijungti").color(NamedTextColor.GOLD))
                        .append(Component.text(" - prijungia prie event.").color(NamedTextColor.DARK_GREEN));
                Component info5 = Component.text("")
                        .append(Component.text("4. /squidglass isjungti").color(NamedTextColor.GOLD))
                        .append(Component.text(" - išjungia event").color(NamedTextColor.DARK_GREEN));

                sender.sendMessage(info0);
                sender.sendMessage(info);
                sender.sendMessage(info2);
                sender.sendMessage(info3);
                sender.sendMessage(info4);
                sender.sendMessage(info5);
            }
            return true;
        }
        return false;
    }


    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (isOn) {
        List<Block> winnerBlokai = addWinnerBlocks(world, winner1, winner2, melynavilna);
        List<Block> deathZone =  vilnosBlokai(world, death1, death2, juodavilna);
            Player player = event.getPlayer();
            Block block = player.getLocation().getBlock().getRelative(0, -1, 0);
            Location blockLocation = block.getLocation();

            boolean isCorrectBlock = false;
            for (Location loc : teisingiBlokai) {
                if (loc.equals(blockLocation)) {
                    praeitiVisiTeisingiBlokai.add(blockLocation);
                    isCorrectBlock = true;
                    break;
                }
            }

            boolean isIncorrectBlock = false;
            for (Location loc : neTeisingiBlokai) {
                if (loc.equals(blockLocation)) {
                    isIncorrectBlock = true;
                    break;
                }
            }

            if (isIncorrectBlock) {
                Location backTP = new Location(world, 745, 222, -2242);
                player.teleport(backTP);
            }

            if (winnerBlokai.contains(block)) {
                if (hasPassedAllCorrectBlocks()) {
                    for(Player zaidejai : Bukkit.getOnlinePlayers()) {
                        zaidejai.playSound(zaidejai.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
                    }
                    Component win = Component.text("")
                            .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                            .append(Component.text("SquidGlass Event").color(NamedTextColor.BLUE))
                            .append(Component.text("] ").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                            .append(Component.text(player.getName()).color(net.kyori.adventure.text.format.NamedTextColor.GOLD))
                            .append(Component.text(" perėjo SquidGlass event'ą!").color(NamedTextColor.AQUA));

                    Location backTP = new Location(world, 745, 222, -2242);
                    player.teleport(backTP);

                    for(Player zaidejai : Bukkit.getOnlinePlayers()) {
                        zaidejai.sendMessage(win);
                    }
                        for(Player zaidejai : Bukkit.getOnlinePlayers()) {
                            zaidejai.playSound(zaidejai.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1f);
                        }
                    istrintiVisaStikla();
                    teisingiBlokai.clear();
                    neTeisingiBlokai.clear();
                    praeitiVisiTeisingiBlokai.clear();
                    Bukkit.getScheduler().runTaskLater(this, this::generateRandomBlocks, 3 * 20L);
                } else {
                    Component cheat = Component.text("")
                            .append(Component.text("Nesukčiauk!").color(NamedTextColor.RED));
                    player.sendMessage(cheat);
                    Location backTP = new Location(world, 745, 222, -2242);
                    player.teleport(backTP);
                }
            }

            if(deathZone.contains(block)) {
                Location backTP = new Location(world, 745, 222, -2242);
                player.teleport(backTP);
            }

            if(noWalkZone(event.getPlayer().getLocation(), noWalk1, noWalk2)) {
                if(!laikasAntBloko.containsKey(player)) {
                    laikasAntBloko.put(player, System.currentTimeMillis());
                } else {
                    long currentTime = System.currentTimeMillis();
                    long startTime = laikasAntBloko.get(player);

                    if(currentTime - startTime >= 500) {
                        Location backTP = new Location(world, 745, 222, -2242);
                        player.teleport(backTP);

                        laikasAntBloko.remove(player);
                    }

                }
            } else {
                laikasAntBloko.remove(event.getPlayer());
            }
        }

        if(!isOn || !dalyvaujantysZaidejai.contains(event.getPlayer())) {
            if(event.getPlayer().getName().equals("//") || event.getPlayer().getName().equals("//")) {
                return;
            }
            if (isWithinCuboid(event.getPlayer().getLocation(), eventZone1, eventZone2)) {
                Location backTP = new Location(world, 745, 222, -2242, 180 ,0 );
                event.getPlayer().teleport(backTP);
                Component denied = Component.text("")
                        .append(Component.text("[").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                        .append(Component.text("SquidGlass Event").color(NamedTextColor.BLUE))
                        .append(Component.text("]").color(net.kyori.adventure.text.format.NamedTextColor.GRAY))
                        .append(Component.text(" Event šiuo metu nevyksta arba jame nedalyvauji!").color(net.kyori.adventure.text.format.NamedTextColor.RED));

                event.getPlayer().sendMessage(denied);
            }
        }


    }

    private void generateRandomBlocks() {

        int stikloPoruKiekis = 13;
        int tarpas = 3;

        for (int i = 0; i < stikloPoruKiekis; i++) {
            int y = 221;
            int z = -2246 -  (i * tarpas);
            int x1 = 746, x2 = 744;



            if (random.nextBoolean()) {
                teisingiBlokai.add(new Location(world, x1, y, z));
                neTeisingiBlokai.add(new Location(world, x2, y, z));
            } else {
                teisingiBlokai.add(new Location(world, x2, y, z));
                neTeisingiBlokai.add(new Location(world, x1, y, z));

            }

            for (Location blokas : teisingiBlokai) {
                blokas.getBlock().setType(stiklas);
            }
            for (Location blokas : neTeisingiBlokai) {
                blokas.getBlock().setType(stiklas);
            }
        }
        for(Player zaidejai : Bukkit.getOnlinePlayers()) {
            zaidejai.playSound(zaidejai.getLocation(), Sound.BLOCK_GLASS_PLACE, 1f, 1f);
        }
    }

    private boolean hasPassedAllCorrectBlocks() {
        return new HashSet<>(praeitiVisiTeisingiBlokai).containsAll(teisingiBlokai);
    }

    private List<Block> addWinnerBlocks(World world, Location winner1, Location winner2, Material melynavilna) {
        List<Block> spotas = new ArrayList<>();
        int minX = Math.min(winner1.getBlockX(), winner2.getBlockX());
        int minY = Math.min(winner1.getBlockY(), winner2.getBlockY());
        int minZ = Math.min(winner1.getBlockZ(), winner2.getBlockZ());
        int maxX = Math.max(winner1.getBlockX(), winner2.getBlockX());
        int maxY = Math.max(winner1.getBlockY(), winner2.getBlockY());
        int maxZ = Math.max(winner1.getBlockZ(), winner2.getBlockZ());

        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    Block block = world.getBlockAt(x, y, z);
                    if (block.getType() == melynavilna) {
                        spotas.add(block);
                    }
                }
            }
        }
        return spotas;
    }

    private List<Block> vilnosBlokai(World world, Location winner1, Location winner2, Material juodavilna) {
        List<Block> spotas = new ArrayList<>();
        int minX = Math.min(winner1.getBlockX(), winner2.getBlockX());
        int minY = Math.min(winner1.getBlockY(), winner2.getBlockY());
        int minZ = Math.min(winner1.getBlockZ(), winner2.getBlockZ());
        int maxX = Math.max(winner1.getBlockX(), winner2.getBlockX());
        int maxY = Math.max(winner1.getBlockY(), winner2.getBlockY());
        int maxZ = Math.max(winner1.getBlockZ(), winner2.getBlockZ());

        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    Block block = world.getBlockAt(x, y, z);
                    if (block.getType() == juodavilna) {
                        spotas.add(block);
                    }
                }
            }
        }
        return spotas;
    }

    private boolean noWalkZone(Location location, Location noWalk1, Location noWalk2) {
        int minX = Math.min(noWalk1.getBlockX(), noWalk2.getBlockX());
        int minY = Math.min(noWalk1.getBlockY(), noWalk2.getBlockY());
        int minZ = Math.min(noWalk1.getBlockZ(), noWalk2.getBlockZ());
        int maxX = Math.max(noWalk1.getBlockX(), noWalk2.getBlockX());
        int maxY = Math.max(noWalk1.getBlockY(), noWalk2.getBlockY());
        int maxZ = Math.max(noWalk1.getBlockZ(), noWalk2.getBlockZ());

        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();

        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    private boolean isWithinCuboid(Location location, Location corner1, Location corner2) {
        int minX = Math.min(corner1.getBlockX(), corner2.getBlockX());
        int minY = Math.min(corner1.getBlockY(), corner2.getBlockY());
        int minZ = Math.min(corner1.getBlockZ(), corner2.getBlockZ());
        int maxX = Math.max(corner1.getBlockX(), corner2.getBlockX());
        int maxY = Math.max(corner1.getBlockY(), corner2.getBlockY());
        int maxZ = Math.max(corner1.getBlockZ(), corner2.getBlockZ());

        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();

        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    private void istrintiVisaStikla() {


            for (Location blokas : teisingiBlokai) {
                blokas.getBlock().setType(Material.AIR);
            }
            for (Location blokas : neTeisingiBlokai) {
                blokas.getBlock().setType(Material.AIR);
            }
    }

    @EventHandler
    public void isjungtiPvP(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player) {
            Player p = (Player) e.getEntity();

            if (dalyvaujantysZaidejai.contains(p)) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void isjungtiBlokuGriovima(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (dalyvaujantysZaidejai.contains(p)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void isjungtiBlokuDejima(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (dalyvaujantysZaidejai.contains(p)) {
            e.setCancelled(true);
        }
    }

}
